To install, copy the included assets folder into your Friday Night Funkin' folder. This demo pack is intended to replace assets in Kade's Engine and may not work correctly in the original game.

+ Bopeebo is replaced by Kaiz Song 1 (final name pending)
+ Fresh is replaced by Kaiz Song 2 (final name pending)
+ Dadbattle is replaced by Kaiz Song 3 (final name pending)
+ Same chart on every difficulty, but different speeds
    + Easy is 1.5x speed
    + Normal is 2.0x speed
    + Hard is 2.5x speed